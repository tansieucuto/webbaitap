const express = require('express');
const router = express.Router();
const orderController = require('../controllers/order.controller');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);
router.post('/', orderController.createOrder);
router.get('/', orderController.listOrders);
router.get('/:orderCode', orderController.getOrder);
router.post('/:orderCode/cancel', orderController.cancelOrder);

module.exports = router;
