const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const config = require('./config/env');
const errorHandler = require('./middleware/errorHandler');

const app = express();

// Bảo mật HTTP headers
app.use(helmet());

// Bật CORS
app.use(cors({
  origin: config.baseUrl,
  credentials: true
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 phút
  max: 100, // Giới hạn mỗi IP 100 request/15p
  message: 'Quá nhiều request từ IP này, vui lòng thử lại sau.'
});
app.use('/api', limiter);

// Parse JSON payload
app.use(express.json());
// Parse URL-encoded body
app.use(express.urlencoded({ extended: true }));
// Parse Cookies
app.use(cookieParser(config.session.secret));

// TODO: Thêm session middleware tại đây (express-session hoặc xử lý token tuỳ chỉnh)

// Mount routers
// app.use('/api/v1/users', require('./routes/userRoutes'));
// app.use('/api/v1/products', require('./routes/productRoutes'));
// app.use('/api/v1/orders', require('./routes/orderRoutes'));

// Route kiểm tra sức khoẻ server
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', timestamp: new Date() });
});

// Xử lý 404 cho các route không tồn tại
app.use((req, res, next) => {
  const { NotFoundError } = require('./utils/errors');
  next(new NotFoundError('Không tìm thấy đường dẫn (Route không tồn tại)'));
});

// Middleware xử lý lỗi toàn cục
app.use(errorHandler);

module.exports = app;
