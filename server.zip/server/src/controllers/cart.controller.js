const pool = require('../config/db');

exports.getCart = async (req, res, next) => {
  try {
    const userId = req.user ? req.user.id : null;
    res.json({ success: true, data: { items: [] } });
  } catch (error) {
    next(error);
  }
};

exports.addItem = async (req, res, next) => {
  try {
    const { variant_id, quantity } = req.body;
    res.json({ success: true, data: { message: 'Đã thêm vào giỏ hàng' } });
  } catch (error) {
    next(error);
  }
};

exports.updateItem = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { quantity } = req.body;
    res.json({ success: true, data: { message: 'Đã cập nhật giỏ hàng' } });
  } catch (error) {
    next(error);
  }
};

exports.removeItem = async (req, res, next) => {
  try {
    const { id } = req.params;
    res.json({ success: true, data: { message: 'Đã xóa khỏi giỏ hàng' } });
  } catch (error) {
    next(error);
  }
};
