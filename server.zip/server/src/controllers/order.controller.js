const pool = require('../config/db');
const generateOrderCode = require('../utils/orderCode');

exports.createOrder = async (req, res, next) => {
  try {
    const orderCode = generateOrderCode();
    res.json({ success: true, data: { orderCode, status: 'pending' } });
  } catch (error) {
    next(error);
  }
};

exports.listOrders = async (req, res, next) => {
  try {
    res.json({ success: true, data: [] });
  } catch (error) {
    next(error);
  }
};

exports.getOrder = async (req, res, next) => {
  try {
    const { orderCode } = req.params;
    res.json({ success: true, data: { orderCode } });
  } catch (error) {
    next(error);
  }
};

exports.cancelOrder = async (req, res, next) => {
  try {
    res.json({ success: true, message: 'Đã hủy đơn hàng' });
  } catch (error) {
    next(error);
  }
};
