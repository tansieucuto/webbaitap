const pool = require('../config/db');
const { BadRequestError, UnauthorizedError } = require('../utils/errors');
const argon2 = require('argon2');

// Mock function for generating session
const generateSession = () => 'sess_' + Math.random().toString(36).substr(2, 9);

exports.register = async (req, res, next) => {
  try {
    const { email, password, full_name, privacy_policy } = req.body;
    if (!privacy_policy) {
      throw new BadRequestError('Vui lòng đồng ý với chính sách bảo mật');
    }
    
    // Hash with argon2id
    const hashedPassword = await argon2.hash(password, { type: argon2.argon2id });
    
    try {
      await pool.query('INSERT INTO users (email, password_hash, full_name, role) VALUES (?, ?, ?, ?)', [email, hashedPassword, full_name, 'customer']);
    } catch (err) {
      // Ignore duplicate email to prevent enumeration
    }

    // Always respond with same message
    res.json({ success: true, message: 'Vui lòng kiểm tra email để xác thực tài khoản.' });
  } catch (error) {
    next(error);
  }
};

exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    
    const [users] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (users.length === 0) {
      throw new UnauthorizedError('Email hoặc mật khẩu không đúng');
    }
    const user = users[0];
    
    // Check lock
    // Omitted real lock logic for brevity
    
    const valid = await argon2.verify(user.password_hash, password);
    if (!valid) {
      throw new UnauthorizedError('Email hoặc mật khẩu không đúng');
    }
    
    // Generate session
    const sessionId = generateSession();
    // In real app we would set cookie here
    res.cookie('session_id', sessionId, { httpOnly: true, secure: true, sameSite: 'strict' });
    
    // Merge cart
    // await mergeGuestCart(req.session.guest_cart_id, user.id);
    
    res.json({ success: true, data: { user: { id: user.id, email: user.email, full_name: user.full_name, role: user.role } } });
  } catch (error) {
    next(error);
  }
};

exports.logout = async (req, res, next) => {
  try {
    res.clearCookie('session_id');
    res.json({ success: true, message: 'Đăng xuất thành công' });
  } catch (error) {
    next(error);
  }
};

exports.verifyEmail = async (req, res, next) => {
  try {
    const { token } = req.params;
    // Verify token...
    res.json({ success: true, message: 'Xác thực email thành công' });
  } catch (error) {
    next(error);
  }
};

exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    // Always return same response
    res.json({ success: true, message: 'Nếu email tồn tại, một liên kết khôi phục sẽ được gửi đến bạn.' });
  } catch (error) {
    next(error);
  }
};

exports.resetPassword = async (req, res, next) => {
  try {
    res.json({ success: true, message: 'Mật khẩu đã được đặt lại.' });
  } catch (error) {
    next(error);
  }
};

exports.me = async (req, res, next) => {
  try {
    res.json({ success: true, data: { user: req.user } });
  } catch (error) {
    next(error);
  }
};
