const pool = require('../config/db');

exports.listProducts = async (req, res, next) => {
  try {
    const [products] = await pool.query('SELECT * FROM products WHERE status = "active"');
    res.json({ success: true, data: products });
  } catch (error) {
    next(error);
  }
};

exports.getProduct = async (req, res, next) => {
  try {
    const { slug } = req.params;
    const [products] = await pool.query('SELECT * FROM products WHERE slug = ?', [slug]);
    if (products.length === 0) {
      return res.status(404).json({ success: false, error: { message: 'Không tìm thấy sản phẩm' } });
    }
    const product = products[0];
    
    const [variants] = await pool.query('SELECT * FROM product_variants WHERE product_id = ?', [product.id]);
    const [images] = await pool.query('SELECT * FROM product_images WHERE product_id = ?', [product.id]);
    
    product.variants = variants;
    product.images = images;
    
    res.json({ success: true, data: product });
  } catch (error) {
    next(error);
  }
};
